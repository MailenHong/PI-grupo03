const express = require ('express');
const router = express.Router();
const productsController = require('../controllers/productController')

router.get('/detalle,')
router.get('/agregarProducto')

module.exports = router;